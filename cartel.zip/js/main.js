function toggleMobileMenu() {
    const menu = document.querySelector('.MenuItems');
    menu.classList.toggle('active');
}